def detect_intent(prompt):
    prompt = prompt.lower()
    if "video" in prompt:
        return "video_generation"
    elif "image" in prompt or "picture" in prompt:
        return "image_generation"
    elif "voice" in prompt or "speech" in prompt:
        return "voice_generation"
    elif "chat" in prompt or "talk" in prompt:
        return "chat_completion"
    return "unknown"
