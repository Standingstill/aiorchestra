import requests

def generate_image(prompt, api_key):
    url = "https://clipdrop-api.co/text-to-image/v1"
    headers = {"x-api-key": api_key}
    payload = {"prompt": prompt}
    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return f"Failed to generate image with Clipdrop: {str(e)}"
