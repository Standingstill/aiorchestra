from flask import Flask, request, jsonify
from orchestrator import handle_prompt, log_usage

app = Flask(__name__)

@app.route("/prompt", methods=["POST"])
def prompt():
    data = request.json
    prompt = data.get("prompt")
    user_api_keys = data.get("api_keys", {})
    user_id = data.get("user_id", "anonymous")

    if not prompt:
        return jsonify({"error": "No prompt provided."}), 400

    result = handle_prompt(prompt, user_api_keys, user_id)
    return jsonify({"result": result})

if __name__ == "__main__":
    app.run(debug=True)
