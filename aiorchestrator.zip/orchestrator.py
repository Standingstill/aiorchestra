from intent_classifier import detect_intent
from apis import invideo_api, dalle_api, elevenlabs_api, runwayml_api, stability_api, clipdrop_api, openrouter_api
import datetime

USAGE_LOG = []

def handle_prompt(prompt, user_api_keys, user_id):
    intent = detect_intent(prompt)
    timestamp = datetime.datetime.utcnow().isoformat()

    if intent == "video_generation":
        if user_api_keys.get("runwayml"):
            log_usage(user_id, intent, "runwayml", timestamp)
            return runwayml_api.generate_video(prompt, user_api_keys["runwayml"])
        elif user_api_keys.get("invideo"):
            log_usage(user_id, intent, "invideo", timestamp)
            return invideo_api.generate_video(prompt, user_api_keys["invideo"])
        elif user_api_keys.get("stability"):
            log_usage(user_id, intent, "stability", timestamp)
            return stability_api.generate_video(prompt, user_api_keys["stability"])
        return "Please provide an API key for RunwayML, Invideo, or Stability."

    elif intent == "image_generation":
        if user_api_keys.get("clipdrop"):
            log_usage(user_id, intent, "clipdrop", timestamp)
            return clipdrop_api.generate_image(prompt, user_api_keys["clipdrop"])
        elif user_api_keys.get("dalle"):
            log_usage(user_id, intent, "dalle", timestamp)
            return dalle_api.generate_image(prompt, user_api_keys["dalle"])
        return "Please provide an API key for Clipdrop or DALL·E."

    elif intent == "voice_generation":
        if user_api_keys.get("elevenlabs"):
            log_usage(user_id, intent, "elevenlabs", timestamp)
            return elevenlabs_api.generate_voice(prompt, user_api_keys["elevenlabs"])
        return "Please provide your ElevenLabs API key."

    elif intent == "chat_completion":
        if user_api_keys.get("openrouter"):
            log_usage(user_id, intent, "openrouter", timestamp)
            return openrouter_api.chat_with_ai(prompt, user_api_keys["openrouter"])
        return "Please provide your OpenRouter API key."

    return "Sorry, I don't know how to handle this prompt yet."

def log_usage(user_id, intent, service, timestamp):
    USAGE_LOG.append({
        "user": user_id,
        "intent": intent,
        "service": service,
        "timestamp": timestamp
    })
